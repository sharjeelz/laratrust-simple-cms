
# laratrust-simple-cms

This is a simpler version of https://github.com/sharjeelz/laravel-laratrust  
If you want to learn about it step by step, visit http://portfolio.sharjeelz.com/laratrust-cms


Laratrust (5.6) CMS

# Steps to Install 

1. Open Command Line where you want to add this project
2. Run "git clone  https://github.com/sharjeelz/laratrust-simple-cms.git"
3. Run "composer update"



# Let me know if you have any issues 

# This also includes Unit Tests.
