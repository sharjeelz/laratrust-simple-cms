<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title','Create User'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<div class="container">
    <div class="content-box">
        <div class="row">
            <div class="col-sm-12">
                <div class="element-wrapper">
                    <div class="element-box">

                        <form enctype="multipart/form-data" action="<?php echo e(url('user/create')); ?>" method="POST" id="formValidate" novalidate="true">
                            <?php echo csrf_field(); ?>
                            <h5 class="form-header">Create User</h5>

                    <fieldset class="form-group">
                        <legend><span>User</span></legend>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group"><label for="">Name</label>
                                    <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
                                    <div class="help-block form-text with-errors form-control-feedback"></div>
                                    <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                    <div class="form-group"><label for="">Email</label>
                                        <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>
                                        <div class="help-block form-text with-errors form-control-feedback"></div>
                                        <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                    </div>
                                </div>
                        </div>
                        <div class="row">
                                <div class="col-sm-6">
                                        <div class="form-group"><label for="">Roles</label>
                                            <select class="roles_pills"  name="roles[]" multiple="multiple" style="width:100%;">
                                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                            <div class="form-group"><label for="">Permissions</label>
                                                <select class="permissions_pills"  name="permissions[]" multiple="multiple" style="width:100%;">
                                                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($permission->id); ?>"><?php echo e($permission->name); ?></option>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                      </select>
                                            </div>
                                        </div>

                        </div>

                        <div class="row">
                            <div class="col-sm-6">
                                    <div class="form-group"><label for="">Picture</label>
                                        <input class="form-control<?php echo e($errors->has('pic') ? ' is-invalid' : ''); ?>" type="file" name="pic"/>
                                        <div class="help-block form-text with-errors form-control-feedback"></div>
                                        <?php if($errors->has('pic')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('pic')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                    </div>
                                </div>


                    </div>
                        <div class="row">
                                <div class="col-sm-6">
                                        <div class="form-group"><label for="">Password</label>
                                            <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
                                            <div class="help-block form-text with-errors form-control-feedback"></div>
                                            <?php if($errors->has('password')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('password')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                            <div class="form-group"><label for="">Confirm Password</label>
                                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                                                <div class="help-block form-text with-errors form-control-feedback"></div>
                                                <?php if($errors->has('password')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                            </div>
                                        </div>

                        </div>


                </fieldset>

                <div
                    class="form-buttons-w"><button class="btn btn-primary disabled" type="submit"> Submit</button></div>
            </form>
        </div>
    </div>
</div>
</div>
 </div>
</div>

<?php $__env->startSection('js'); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<script>
$(document).ready(function() {
    $('.permissions_pills').select2();
    $('.roles_pills').select2();
});
</script>

<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>