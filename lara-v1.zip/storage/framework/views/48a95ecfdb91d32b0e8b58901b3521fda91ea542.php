<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title','Roles'); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<div class="container">
    <h6 class="element-header">System Permissions</h6>
    <div style="text-align:right;margin:12px;"><a class="btn btn-success btn-md" href="<?php echo e(url('permission/create')); ?>"><i class="fa fa-cross"></i><span>Add Permission</span></a> </div>
    <div class="table-responsive">
        <table id="usertable" width="100%" class="table table-striped table-lightfont">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Display Name</th>
                            <th>Description</th>
                            <th>Created at</th>
                            <th>Updated at</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($permission->name); ?></td>
                        <td><?php echo e($permission->display_name); ?></td>
                        <td><?php echo e($permission->description); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($permission->created_at)->format('d/m/Y h:i:s A')); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($permission->updated_at)->format('d/m/Y h:i:s A')); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>