<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title','Roles'); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<div class="container">
    <h6 class="element-header">System Roles</h6>
    <div style="text-align:right;margin:12px;"><a class="btn btn-success btn-md" href="<?php echo e(url('role/create')); ?>"><i class="fa fa-cross"></i><span>Add Role</span></a> </div>
    <div class="table-responsive">
        <table id="usertable" width="100%" class="table table-striped table-lightfont">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Display Name</th>
                            <th>Description</th>
                            <th>Created at</th>
                            <th>Updated at</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($role->name); ?></td>
                        <td><?php echo e($role->display_name); ?></td>
                        <td><?php echo e($role->description); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($role->created_at)->format('d/m/Y h:i:s A')); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($role->updated_at)->format('d/m/Y h:i:s A')); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>