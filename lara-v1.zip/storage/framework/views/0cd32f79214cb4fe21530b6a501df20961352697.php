<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title','Users'); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<div class="container">
    <h6 class="element-header">System Users</h6>
    <div style="text-align:right;margin:12px;"><a class="btn btn-success btn-md" href="<?php echo e(url('register')); ?>"><i class="fa fa-cross"></i><span>Add User</span></a> </div>

    <div class="table-responsive">
        <table id="usertable" width="100%" class="table table-striped table-lightfont">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Date Created</th>
                            <th>Last Updated</th>
                            <th>Role <i>(s)</i></th>
                            <th>Permission <i>(s)</i></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($user->created_at)->format('d/m/Y h:i:s A')); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($user->updated_at)->format('d/m/Y h:i:s A')); ?></td>
                        <td>
                            <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($role->name); ?>.
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td>
                            <?php $__currentLoopData = $user->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($permission->name); ?>.
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>